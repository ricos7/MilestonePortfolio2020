#this function isntalls the package if you don't have it already
packageCheck <- function(x){
  x <- as.character(x)
  
  if (!require(x,character.only = TRUE)){
    install.packages(pkgs=x,repos = "http://cran.us.r-project.org")
    require(x,character.only = TRUE)
  }
}
# check each dependency to see if its loaded, if not 
packageCheck("readr")
packageCheck("e1071")
packageCheck("class")
library(randomForest)
library(e1071)
library(readr)
library(openxlsx)
library(naivebayes)
library(class)

# load in data and get structure
data <- read.csv("C:/Users/jesse/OneDrive/Documents/DataAnalytics/FinalProject/SyracuseDataAnalytics/EDA - Practice/cleanAttributes_Local.csv"
                 ,header=TRUE,  stringsAsFactors=TRUE)



###*** CONVERT DATA *** ###
data$newTimeHandoff <- gsub("T"," ",data$TimeHandoff)
data$newTimeHandoff <- strftime(data$newTimeHandoff, format = "%Y-%m-%d %H:%M:%S", tz="UTC")
data$newTimeSnap <- gsub("T"," ",data$TimeSnap)
data$newTimeSnap <- strftime(data$newTimeSnap, format = "%Y-%m-%d %H:%M:%S", tz="UTC")
data$timeToHandoff <- difftime(data$newTimeHandoff,data$newTimeSnap, units=c("secs"))
data$timeToHandoff <- as.factor(data$timeToHandoff)
data$Yards <- as.numeric(data$Yards)

# If progress, 1, if no progress, set to 0
data$ProgressYN <- 0 
data$ProgressYN <- ifelse(data$Yards <=0, "N","Y")


# how many were progressions, how many were not progressions
#hist(data$ProgressYN)

# add time from timesnap - timehandoff


# set factors and numbers

data$Distance <- as.numeric(data$Distance)
data$HomeScoreBeforePlay <- as.numeric(data$HomeScoreBeforePlay)
data$VisitorScoreBeforePlay <- as.numeric(data$VisitorScoreBeforePlay)
data$DefendersInTheBox <- as.numeric(data$DefendersInTheBox)
data$Quarter <- as.factor(data$Quarter)
data$YardLine <- as.numeric(data$YardLine)
data$ProgressYN <- as.factor(data$ProgressYN)

#tier 3
# dataSelect <- subset(data, select=c(
#   'OffenseFormation','HomeScoreBeforePlay','VisitorScoreBeforePlay','Distance','Quarter','YardLine',
#   'DefendersInTheBox','PlayDirection',"timeToHandoff",
#   'ProgressYN'
# 
# ))
#tier 2
# dataSelect <- subset(data, select=c(
#   'OffenseFormation','Distance','YardLine',
#   'DefendersInTheBox',"timeToHandoff",
#   'ProgressYN'
#  
# ))

# tier 1
dataSelect <- subset(data, select=c(
  'OffenseFormation',
  'DefendersInTheBox',
  'ProgressYN'

))



dataSelect <- na.omit(dataSelect) 

# random forest
#kfolds 
N <- nrow(dataSelect)
kfolds <- 3
holdout <- split(sample(1:N), 1:kfolds)



all_results <- data.frame(orig=c(), pred=c())
for (k in 1:kfolds) {
  new_test <- dataSelect[holdout[[k]], ]
  new_train <- dataSelect[-holdout[[k]], ]
  
  new_test_no_label <- new_test[-c(3)]
  new_test_just_label <- new_test[c(3)]
  
  test_model <- randomForest(ProgressYN ~ ., new_train, na.action=na.pass,ntree=100 )
  pred <- predict(test_model, new_test_no_label, type=c("class"))
  
  all_results <- rbind(all_results, data.frame(orig=new_test_just_label$ProgressYN, pred=pred))
}
table(all_results$orig, all_results$pred)

