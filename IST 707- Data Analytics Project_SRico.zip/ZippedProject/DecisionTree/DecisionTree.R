#this function isntalls the package if you don't have it already
packageCheck <- function(x){
  x <- as.character(x)
  
  if (!require(x,character.only = TRUE)){
    install.packages(pkgs=x,repos = "http://cran.us.r-project.org")
    require(x,character.only = TRUE)
  }
}
# check each dependency to see if its loaded, if not 
packageCheck("readr")
packageCheck("rpart")
library(readr)
library(rpart)
library(rattle)


# load in data and get structure
data <- read.csv("C:/Users/jesse/OneDrive/Documents/DataAnalytics/FinalProject/SyracuseDataAnalytics/EDA - Practice/cleanAttributes_Local.csv"
                 ,header=TRUE,  stringsAsFactors=TRUE)

data$GameId <- factor(data$GameId)

###*** CONVERT DATA *** ###
data$newTimeHandoff <- gsub("T"," ",data$TimeHandoff)
data$newTimeHandoff <- strftime(data$newTimeHandoff, format = "%Y-%m-%d %H:%M:%S", tz="UTC")
data$newTimeSnap <- gsub("T"," ",data$TimeSnap)
data$newTimeSnap <- strftime(data$newTimeSnap, format = "%Y-%m-%d %H:%M:%S", tz="UTC")
data$timeToHandoff <- difftime(data$newTimeHandoff,data$newTimeSnap, units=c("secs"))
data$timeToHandoff <- as.factor(data$timeToHandoff)

# If progress, 1, if no progress, set to 0
data$ProgressYN <- 0 
data$ProgressYN <- ifelse(data$Yards <=0, "N","Y")
#data$ProgressYN <- as.factor(data$Yards)


# how many were progressions, how many were not progressions
#hist(data$ProgressYN)

# add time from timesnap - timehandoff


# set factors and numbers

data$Distance <- as.numeric(data$Distance)
data$HomeScoreBeforePlay <- as.numeric(data$HomeScoreBeforePlay)
data$VisitorScoreBeforePlay <- as.numeric(data$VisitorScoreBeforePlay)
data$DefendersInTheBox <- as.numeric(data$DefendersInTheBox)
data$Quarter <- as.factor(data$Quarter)
data$YardLine <- as.numeric(data$YardLine)
data$ProgressYN <- as.factor(data$ProgressYN)
# data$FirstDown <- ifelse(data$Yards>=data$Distance,'Y','N')

#remove data not needed
dataSelect <- subset(data, select=c(
  'OffenseFormation',
  'DefendersInTheBox',
  'ProgressYN',
  'YardLine',
  "timeToHandoff",
  'Distance'
  # commented out data   'OffensePersonnel',  'HomeScoreBeforePlay',  'VisitorScoreBeforePlay',  'Quarter',  'PlayDirection',
))
na.omit(dataSelect)

# define folds
trainRatio <- .8
set.seed(13)
sample <- sample.int(n=nrow(dataSelect), size=floor(trainRatio*nrow(dataSelect)), replace=FALSE)
train <- dataSelect[sample, ]
test <- dataSelect[-sample, ]
# train / test ratio
length(sample)/nrow(dataSelect)

tree <- rpart(
  ProgressYN ~ .,
  data = train, 
  method ="class",
  control = rpart.control(cp=0, method="class")
)

summary(tree)

# fancyRpartPlot(tree)
predicted= predict(tree, test, type="class")
table(Progression= predicted, true=test$ProgressYN)



