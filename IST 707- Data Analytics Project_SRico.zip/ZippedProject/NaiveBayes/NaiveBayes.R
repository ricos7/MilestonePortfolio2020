#this function isntalls the package if you don't have it already
packageCheck <- function(x){
  x <- as.character(x)
  
  if (!require(x,character.only = TRUE)){
    install.packages(pkgs=x,repos = "http://cran.us.r-project.org")
    require(x,character.only = TRUE)
  }
}
# check each dependency to see if its loaded, if not 
packageCheck("readr")
packageCheck("e1071")
library(e1071)
library(readr)
library(openxlsx)
library(naivebayes)


# load in data and get structure
data <- read.csv("C:/Users/jesse/OneDrive/Documents/DataAnalytics/FinalProject/SyracuseDataAnalytics/EDA - Practice/cleanAttributes_Local.csv"
                 ,header=TRUE,  stringsAsFactors=TRUE)

data$GameId <- factor(data$GameId)

###*** CONVERT DATA *** ###
data$newTimeHandoff <- gsub("T"," ",data$TimeHandoff)
data$newTimeHandoff <- strftime(data$newTimeHandoff, format = "%Y-%m-%d %H:%M:%S", tz="UTC")
data$newTimeSnap <- gsub("T"," ",data$TimeSnap)
data$newTimeSnap <- strftime(data$newTimeSnap, format = "%Y-%m-%d %H:%M:%S", tz="UTC")
data$timeToHandoff <- difftime(data$newTimeHandoff,data$newTimeSnap, units=c("secs"))
data$timeToHandoff <- as.factor(data$timeToHandoff)

# If progress, 1, if no progress, set to 0
data$ProgressYN <- 0 
data$ProgressYN <- ifelse(data$Yards <=0, "N","Y")
#data$ProgressYN <- as.factor(data$Yards)


# how many were progressions, how many were not progressions
#hist(data$ProgressYN)

# add time from timesnap - timehandoff


# set factors and numbers
str(dataSelect)
data$Distance <- as.numeric(data$Distance)
data$HomeScoreBeforePlay <- as.numeric(data$HomeScoreBeforePlay)
data$VisitorScoreBeforePlay <- as.numeric(data$VisitorScoreBeforePlay)
data$DefendersInTheBox <- as.numeric(data$DefendersInTheBox)
data$Quarter <- as.factor(data$Quarter)
data$YardLine <- as.numeric(data$YardLine)
data$ProgressYN <- as.factor(data$ProgressYN)

#remove data not needed
dataSelect <- subset(data, select=c(
  'OffenseFormation','HomeScoreBeforePlay','VisitorScoreBeforePlay','Distance','Quarter','YardLine',
  'DefendersInTheBox','PlayDirection',"timeToHandoff",
  'ProgressYN'
  # commented out data 'OffensePersonnel'
))

# removed 'OffensePersonnel'45
# remove empty and ace formations 


# create random sample in data set
N <- nrow(dataSelect)
kfolds <- 2
holdout <- split(sample(1:N),1:kfolds)

# Run tranining and testing for each fold
AllResults <- list()
AllLabels <- list()

for (k in 1:kfolds){
  dataSelect_Test=dataSelect[holdout[[k]],]
  dataSelect_Train=dataSelect[-holdout[[k]],]
  # take out labels of testing

  dataSelect_Test_noLabel <- dataSelect_Test[-c(10)]
  dataSelect_justLabel <- dataSelect_Test$ProgressYN
  
  # e1071 Naive Bayes
  NB_e1071<-naiveBayes(ProgressYN~., data=dataSelect_Train, na.action = na.pass)
  NB_e1071_Pred <- predict(NB_e1071, dataSelect_Test_noLabel)
  NB_e1071
  
  ## Accumulate results from each fold
  AllResults<- c(AllResults,NB_e1071_Pred)
  AllLabels<- c(AllLabels, dataSelect_justLabel)
  
  
}

table(unlist(AllResults),unlist(AllLabels))

# other model

NB_object<- naive_bayes(ProgressYN~., laplace = 0 , data=dataSelect_Train)
NB_prediction<-predict(NB_object, dataSelect_Test_noLabel , type = c("class"))
head(predict(NB_object, dataSelect_Test_noLabel, type = "prob"))

table(NB_prediction,dataSelect_justLabel)

plot(NB_object, legend.box = TRUE)



